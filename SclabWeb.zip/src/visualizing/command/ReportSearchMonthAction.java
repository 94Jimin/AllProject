package visualizing.command;

public class ReportSearchMonthAction {

}
