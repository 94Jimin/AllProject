package visualizing.command;

public class ReportSearchDayAction {

}
