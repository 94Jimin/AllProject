package visualizing.command;

public class AnalysisSearchDayAction {

}
