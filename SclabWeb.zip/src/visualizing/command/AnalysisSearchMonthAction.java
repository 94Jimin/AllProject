package visualizing.command;

public class AnalysisSearchMonthAction {

}
