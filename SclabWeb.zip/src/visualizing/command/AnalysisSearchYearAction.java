package visualizing.command;

public class AnalysisSearchYearAction {

}
