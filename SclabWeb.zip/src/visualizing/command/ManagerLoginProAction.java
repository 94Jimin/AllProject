package visualizing.command;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import visualizing.util.DbConnector;



public class ManagerLoginProAction implements CommandAction {
	
	public String checkId(String id, String pw) {

		DbConnector dbconnector = new DbConnector();
		Connection conn = dbconnector.getConn();
		PreparedStatement pstmt = dbconnector.getPstmt();

		String sql = "select strcmp((select SHA2(\"" + pw
				+ "\",512)),(select password from ADMIN where id =\"" + id
				+ "\")) as checkId;"; // 쿼리
		String value = null;

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				value = rs.getString("checkId");
			}

			rs.close();
			pstmt.close();
			conn.close();
			dbconnector.disconnect();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return value;
	} // 아디와 비밀번호 체크하는 함수


	@Override
	public String requestPro(HttpServletRequest request,
			HttpServletResponse response) throws Throwable {

		request.setCharacterEncoding("utf-8");

		String id = request.getParameter("userId");
		String passwd = request.getParameter("userPasswd");

		int check = 0;
		String result = checkId(id,passwd);
		if (result != null && result.equals("0")){
			check = 1;
		} else {
			check=0;
			//return "/index.jsp";
	     }
		
		request.setAttribute("check", new Integer(check));
		request.setAttribute("id", id);

		return "/logon/loginPro.jsp";
	}

	
}
